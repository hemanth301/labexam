package com.klef.jfsd.exam.service;

import com.klef.jfsd.exam.model.Customer;
import java.util.List;

public interface CustomerService {
    List<Customer> getAllCustomers();
} 